package cpsc411.simplehttpclient

data class Claim(var claimName:String?, var date:String?)